<html>
  <head>
    <title> Latihan 8.6 </title>
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body style="background-color:#4d79ff;">
    <div>
        <br>
        <center>
            <h2> Latihan 8.6 </h2>
        </center>
        <br>

        <table align="center">
            <form method="POST" action="proseslogin.php">

                <tr>
                    <td>Username</td>
                    <td><input type="text" class="form-control form-control-lg" name="username" required> </td>
                </tr>
                <tr>
                    <td>Password</td>
                    <td><input type="password" class="form-control form-control-lg" name="password" required> </td>
                </tr>
                <br>
                <tr>
                    <td></td>
                    <td><input type="submit" class="btn btn-warning" name="login" value="Login"></td>
                </tr>
            </form>

        </table>
    </div>
  </body>
</html>

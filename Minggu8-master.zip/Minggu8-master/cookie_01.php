<?php
$value = 'Billy';
$value2 = 'Billy Titan';
setcookie("Username", $value);
setcookie("NamaLengkap", $value2, time() + 3600);
/* expire in 1 hour */
echo "<h1>Ini halaman pengesetan cookie</h1>";
echo "<h2>Klik <a href='cookie_02.php'>di sini</a> untuk
pemeriksaan cookies</h2>";
?>
